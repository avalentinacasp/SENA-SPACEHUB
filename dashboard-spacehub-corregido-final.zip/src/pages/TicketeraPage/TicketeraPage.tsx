import { useState } from 'react';
import './TicketeraPage.css';

type Ticket = { equipo: string; prioridad: 'Alta' | 'Media'; descripcion: string; resuelto: boolean };

export default function TicketeraPage() {
  const [tickets, setTickets] = useState<Ticket[]>([
    { equipo: 'SENA-1002', prioridad: 'Alta', descripcion: 'Falla en el teclado y puerto HDMI intermitente', resuelto: false },
    { equipo: 'SENA-1005', prioridad: 'Media', descripcion: 'Batería no retiene carga más de 30 minutos', resuelto: false },
  ]);

  const resolver = (equipo: string) => setTickets((items) => items.map((t) => t.equipo === equipo ? { ...t, resuelto: true } : t));

  return (
    <div className="spacehub-page ticketera-page">
      <section className="spacehub-page-heading">
        <div>
          <h1>Mesa de Ayuda y Ticketera de Fallas</h1>
          <p>Reportes de fallas técnicas e incidencias de hardware</p>
        </div>
        <button className="ticket-report-btn">🛠️ Reportar Incidencia</button>
      </section>
      <section className="tickets-list">
        {tickets.map((ticket) => (
          <article className={`ticket-card ${ticket.resuelto ? 'resolved' : ''}`} key={ticket.equipo}>
            <div className="ticket-main">
              <div className="ticket-meta">
                <span className="ticket-equipo">{ticket.equipo}</span>
                <span className={`priority ${ticket.prioridad === 'Alta' ? 'high' : 'medium'}`}>Prioridad {ticket.prioridad}</span>
              </div>
              <p>{ticket.descripcion}</p>
            </div>
            <button className="resolve-btn" onClick={() => resolver(ticket.equipo)} disabled={ticket.resuelto}>
              {ticket.resuelto ? '✓ Ticket Resuelto' : 'Resolver Ticket'}
            </button>
          </article>
        ))}
      </section>
    </div>
  );
}
