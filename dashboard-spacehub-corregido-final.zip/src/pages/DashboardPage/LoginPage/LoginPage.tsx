import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth, RolUsuario } from '../../../context/AuthContext';
import './LoginPage.css';

// Usuarios de prueba. Cuando se conecte el login con FastAPI,
// esta validación se reemplazará por la autenticación de la API.
const USUARIOS_VALIDOS: Record<RolUsuario, string[]> = {
  aprendiz: ['aprendiz', 'ashli castañeda', 'ashli valentina castañeda zabala'],
  administrador: ['administrador', 'bladimir murcia', 'bladimir alejandro murcia rozo'],
};

export default function LoginPage() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [usuario, setUsuario] = useState('');
  const [rol, setRol] = useState<RolUsuario>('aprendiz');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const nombre = usuario.trim().toLowerCase();

    // No permite entrar si el campo está vacío.
    if (!nombre) {
      setError('Debes ingresar un nombre de usuario.');
      return;
    }

    // Verifica que el usuario exista para el rol seleccionado.
    if (!USUARIOS_VALIDOS[rol].includes(nombre)) {
      setError(
        rol === 'administrador'
          ? 'Usuario administrador no válido. Usa: Bladimir Murcia'
          : 'Usuario aprendiz no válido. Usa: Ashli Castañeda'
      );
      return;
    }

    setError('');
    const nombreMostrar = rol === 'administrador' ? 'Bladimir Murcia' : 'Ashli Castañeda';
    login({
      nombre: nombreMostrar,
      rol,
    });
    navigate('/dashboard', { replace: true });
  };

  return (
    <div className="login-page">
      <form className="login-form" onSubmit={handleSubmit}>
        <div className="login-brand">SENA SpaceHub</div>
        <h2>Iniciar Sesión</h2>
        <p className="login-subtitle">Selecciona el tipo de usuario para continuar</p>

        <input
          value={usuario}
          onChange={(e) => {
            setUsuario(e.target.value);
            if (error) setError('');
          }}
          placeholder="Nombre de usuario"
          autoComplete="username"
          aria-label="Nombre de usuario"
        />

        {error && <p className="login-error" role="alert">{error}</p>}

        <div className="role-options">
          <button
            type="button"
            className={`role-card ${rol === 'aprendiz' ? 'selected' : ''}`}
            onClick={() => {
              setRol('aprendiz');
              setError('');
            }}
          >
            <span>🎓</span>
            <strong>Aprendiz</strong>
            <small>Consulta tu información y novedades</small>
          </button>

          <button
            type="button"
            className={`role-card ${rol === 'administrador' ? 'selected' : ''}`}
            onClick={() => {
              setRol('administrador');
              setError('');
            }}
          >
            <span>🛡️</span>
            <strong>Administrador</strong>
            <small>Gestiona aprendices, fichas e inventario</small>
          </button>
        </div>

        <button className="login-button" type="submit">Entrar como {rol}</button>

        <small className="login-hint">
          Prueba: <strong>Ashli Castañeda</strong> o <strong>Bladimir Murcia</strong>
        </small>
      </form>
    </div>
  );
}
