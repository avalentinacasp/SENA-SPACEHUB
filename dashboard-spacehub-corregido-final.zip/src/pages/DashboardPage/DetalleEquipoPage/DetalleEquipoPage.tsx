import { useParams } from 'react-router-dom';
import './DetalleEquipoPage.css';

export default function DetalleEquipoPage() {
  // Extraemos la variable :placaSena definida en el 
  const { placaSena } = useParams<{ placaSena: string }>();

  return (
    <div className="detalle-equipo-page">
      <h2>Ficha Técnica del Computador</h2>
      <p>Placa SENA Consultada: <strong>{placaSena}</strong></p>
    </div>
  );
}