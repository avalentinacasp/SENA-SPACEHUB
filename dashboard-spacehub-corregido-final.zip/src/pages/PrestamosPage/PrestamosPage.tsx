import { useState } from 'react';
import './PrestamosPage.css';

type Prestamo = { ficha: string; nombre: string; equipo: string; hora: string; estado: 'Activo' | 'Pendiente' };

export default function PrestamosPage() {
  const [prestamos, setPrestamos] = useState<Prestamo[]>([
    { ficha: '#2879451', nombre: 'Ashli Castañeda', equipo: 'SENA-1001', hora: '08:00 AM', estado: 'Activo' },
    { ficha: '#2879451', nombre: 'Carlos Mendoza', equipo: 'SENA-1003', hora: '09:30 AM', estado: 'Activo' },
    { ficha: '#2879432', nombre: 'Jennifer Andrea', equipo: 'SENA-1004', hora: '10:15 AM', estado: 'Pendiente' },
  ]);

  const registrarDevolucion = (nombre: string) => {
    setPrestamos((items) => items.map((p) => p.nombre === nombre ? { ...p, estado: 'Pendiente' } : p));
  };

  return (
    <div className="spacehub-page prestamos-page">
      <section className="spacehub-page-heading">
        <div>
          <h1>Gestión de Solicitudes de Préstamo</h1>
          <p>Control de entregas y devoluciones para aprendices e instructores</p>
        </div>
        <button className="spacehub-primary-btn">📋 Solicitar Préstamo de Equipo</button>
      </section>

      <section className="prestamos-grid">
        {prestamos.map((prestamo) => (
          <article className="prestamo-card" key={prestamo.nombre}>
            <div className="prestamo-top">
              <span className="ficha-tag">Ficha {prestamo.ficha}</span>
              <span className="prestamo-time">{prestamo.hora}</span>
            </div>
            <h2>{prestamo.nombre}</h2>
            <p>Equipo: <strong>{prestamo.equipo}</strong></p>
            <button
              className="return-btn"
              onClick={() => registrarDevolucion(prestamo.nombre)}
              disabled={prestamo.estado === 'Pendiente'}
            >
              {prestamo.estado === 'Pendiente' ? '🕒 Devolución registrada' : '☑ Registrar Devolución'}
            </button>
          </article>
        ))}
      </section>
    </div>
  );
}
