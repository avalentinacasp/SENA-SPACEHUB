import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth, RolUsuario } from '../context/AuthContext';

interface ProtectedRouteProps {
  children: React.ReactNode;
  rolesPermitidos?: RolUsuario[];
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, rolesPermitidos }) => {
  const { user, isAuthenticated } = useAuth();

  if (!isAuthenticated) return <Navigate to="/login" replace />;

  if (rolesPermitidos && (!user || !rolesPermitidos.includes(user.rol))) {
    return <Navigate to="/dashboard" replace />;
  }

  return <>{children}</>;
};
