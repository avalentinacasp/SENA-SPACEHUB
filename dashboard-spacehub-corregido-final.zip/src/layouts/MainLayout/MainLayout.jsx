import { Outlet } from 'react-router-dom';
import Navbar from '../../components/Navbar/Navbar';
import './MainLayout.css';
export default function MainLayout(){return <div className="layout-wrapper"><Navbar/><main className="layout-content"><Outlet/></main></div>}
