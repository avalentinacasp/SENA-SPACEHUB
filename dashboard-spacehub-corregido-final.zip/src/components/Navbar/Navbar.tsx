import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import './Navbar.css';
export default function Navbar(){
 const {user,logout}=useAuth(); const navigate=useNavigate(); const esAdmin=user?.rol==='administrador';
 const salir=()=>{logout();navigate('/login',{replace:true});};
 return <header className="spacehub-header">
  <div className="spacehub-topbar"><div className="spacehub-brand-wrap"><span className="spacehub-brand">SENA SpaceHub</span><span className="spacehub-center">Centro de Gestión de Mercados, Logística y TI</span></div>
   <nav className="spacehub-nav">
    <NavLink to="/dashboard" className={({isActive})=>isActive?'spacehub-nav-link active':'spacehub-nav-link'}>📊 Dashboard</NavLink>
    {esAdmin&&<NavLink to="/inventario" className={({isActive})=>isActive?'spacehub-nav-link active':'spacehub-nav-link'}>💻 Inventario (5)</NavLink>}
    <NavLink to="/prestamos" className={({isActive})=>isActive?'spacehub-nav-link active':'spacehub-nav-link'}>📋 Préstamos (3)</NavLink><NavLink to="/ticketera" className={({isActive})=>isActive?'spacehub-nav-link active':'spacehub-nav-link'}>🛠️ Ticketera (2)</NavLink>
   </nav>
  </div>
  <div className="spacehub-user-row"><div className="spacehub-user-pill"><span className="online-dot"/><strong>{user?.nombre}</strong><span className={`spacehub-role ${esAdmin?'admin':'aprendiz'}`}>{esAdmin?'Administrador':'Aprendiz'}</span><button className="spacehub-logout" onClick={salir}>Salir</button></div></div>
  <div className="spacehub-info-row"><span>🧑‍💻</span><span>Modo {esAdmin?'Administrador':'Aprendiz'} activo</span><span className="info-separator">•</span><span>Las solicitudes de préstamo autocompletan tus datos personales.</span><span className="info-spacer"/><span className="switch-role">⚡ Cambiar a {esAdmin?'Aprendiz':'Operador/Admin'}</span></div>
 </header>
}
