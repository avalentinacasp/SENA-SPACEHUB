import './TarjetaFicha.css';
import { useState } from 'react';

function TarjetaFicha({ ficha, programa, instructor, jornada, estado, onAbrirModal }) {
const [asistio, setAsistio] = useState(estado === 'Activa');
  return (
    <div className="tarjeta-ficha">
      <div className="tarjeta-header">
        <span className="badge-ficha">{ficha}</span>
        <button 
          onClick={() => setAsistio(!asistio)}
          className={`btn-asistencia ${asistio ? 'asistio' : 'ausente'}`}
        >
          {asistio ? '✅ Asistencia: Marcada' : '❌ Asistencia: Ausente'}
        </button>
      </div>
      <h4 className="tarjeta-titulo">{programa}</h4>
      <p className="tarjeta-instructor">Instructor: {instructor}</p>
      
      {onAbrirModal && (
        <div className="tarjeta-acciones">
          <button onClick={onAbrirModal} className="btn-modal-trigger">
            💬 Ver Novedades (Modal)
          </button>
        </div>
      )}
    </div>

  );
}

export default TarjetaFicha