import './ModalNovedad.css';

function ModalNovedad({ onClose }) {
  return (
    <div className="modal-overlay">
      <div className="modal-container">
        <div className="modal-header">
          <div className="modal-title-box">
            <span className="badge-novedad">💬 Novedad</span>
            <h4 className="modal-title">Ficha #2879451</h4>
          </div>
          {/* Al presionar '✕' ejecutamos onClose */}
          <button onClick={onClose} className="btn-close">✕</button>
        </div>
        <p className="modal-body">
          Recordatorio: Entrega de evidencias de maquetación y componentes React programada para este viernes antes de medianoche.
        </p>
        <button 
          onClick={onClose} 
          className="btn-modal-action">
          Entendido y Cerrar Modal
        </button>
      </div>
    </div>
  );
}

export default ModalNovedad;