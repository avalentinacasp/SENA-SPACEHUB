import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import './PerfilPage.css';

export default function PerfilPage() {
  const { user } = useAuth();
  const [mostrarFoto, setMostrarFoto] = useState(false);
  const esAdmin = user?.rol === 'administrador';
  const nombre = user?.nombre || 'Usuario';

  return (
    <div className="perfil-container">
      <div className="perfil-card">
        <div className="perfil-header">
          <div className="perfil-header-brand">
            <span className="perfil-badge-sena">SENA</span>
            <span className="perfil-ficha">SENA SpaceHub</span>
          </div>
          <span className="perfil-estado">● Activo</span>
        </div>
        <div className="perfil-body">
          {mostrarFoto && (
            <div className="perfil-foto-container">
              <div className="perfil-avatar">{esAdmin ? '🛡️' : '🎓'}</div>
            </div>
          )}
          <div>
            <h5 className="perfil-nombre">{nombre}</h5>
            <p className="perfil-programa">{esAdmin ? 'Administrador' : 'Aprendiz ADSO'} • SENA SpaceHub</p>
            <p className="perfil-centro">Centro de Gestión de Mercados, Logística y TI</p>
          </div>
          <div className="perfil-datos">
            <div className="perfil-dato-fila">
              <span className="perfil-dato-label">Rol:</span>
              <span className="perfil-dato-valor">{esAdmin ? 'Administrador' : 'Aprendiz'}</span>
            </div>
            <div className="perfil-dato-fila">
              <span className="perfil-dato-label">Estado:</span>
              <span className="perfil-dato-valor">Activo</span>
            </div>
          </div>
          <button onClick={() => setMostrarFoto(!mostrarFoto)} className="perfil-btn-toggle">
            <span>{mostrarFoto ? '👁️' : '👤'}</span>
            <span>{mostrarFoto ? 'Ocultar Perfil' : 'Mostrar Perfil'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
